package mini.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/HomePage")
public class HomePage extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session= req.getSession();
		String usn= (String)session.getAttribute("user");
		
		if(usn!=null)
		{
			RequestDispatcher rd= req.getRequestDispatcher("loginSucess.html");
		}
		else
		{
			PrintWriter p= resp.getWriter();
			p.print("<html><body>");
			p.print("<h1> Login First </h1>");
			p.print("</body></html>");
		}
	}
}
