package mini.project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Register extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// id, name, email, password
		String idd= req.getParameter("idd");
		int id= Integer.parseInt(idd);
		String name= req.getParameter("name");
		String email= req.getParameter("email");
		String password= req.getParameter("password");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sample-servlet-jdbc","root","harsh");
			
			String querry= "insert into loginpro values(?,?,?,?)";
			PreparedStatement ps= con.prepareStatement(querry);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, email);
			ps.setString(4, password);
			
			ps.executeUpdate();
			
//			PrintWriter p= resp.getWriter();
//			p.print("<html>,body>");
//			p.print("<h1> Register Sucessfully </h1>");
//			p.print("</body></html>");
			RequestDispatcher rd= req.getRequestDispatcher("registerSucess.html");
			rd.forward(req, resp);
			
//			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
